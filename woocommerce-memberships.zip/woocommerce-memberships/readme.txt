=== WooCommerce Memberships ===
Author: skyverge
Tags: woocommerce
Requires at least: 4.4
Tested up to: 5.5
Requires PHP: 5.6

See https://docs.woocommerce.com/document/woocommerce-memberships/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-memberships' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
